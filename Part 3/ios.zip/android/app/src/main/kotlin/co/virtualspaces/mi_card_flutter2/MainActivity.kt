package co.virtualspaces.mi_card_flutter2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
