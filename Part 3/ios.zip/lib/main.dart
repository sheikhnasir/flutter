import 'package:flutter/material.dart';

int _counter = 0;
void main() {
  runApp(MyApp());
}

class MainPage extends StatefulWidget {
  const MainPage({Key? key}) : super(key: key);

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: const Text('My Apps'),
      ),
      body: const Center(
        child: Text('My Name is Sheikh'),
      ),
    );
  }
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        backgroundColor: Colors.blueAccent,
        appBar: AppBar(
          backgroundColor: Colors.blueGrey,
          title: const Text('My Apps'),
        ),
        body: SafeArea(
          child: Row(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Container(
                  height: 100.0,
                  width: 100.0,
//margin: EdgeInsets.all(20.0),

                  color: Colors.white,
                  child: Text('Container 1'),
                ),
                Container(
                  width: 100,
                  height: 100,
                  color: Colors.red,
                  child: Text('Container 2'),
                ),
                SizedBox(
                  width: 20,
                  child: Text('Boxed'),
                ),
                Container(
                  width: 100,
                  height: 100,
                  color: Colors.green,
                  child: Text('Container 2'),
                ),
              ]),
        ),
      ),
      debugShowCheckedModeBanner: false,
    );
  }
}
