package co.virtualspaces.skim_cepat_kaya

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
